package com.maxdexter.criminalintent;

public class CrimeLab {
}
